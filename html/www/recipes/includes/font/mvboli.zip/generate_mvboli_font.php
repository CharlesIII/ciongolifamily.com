<?php

require('../fpdf/makefont/makefont.php');

MakeFont('mvboli.ttf','cp1252');

?>