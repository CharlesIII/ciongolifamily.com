<?php

ini_set('display_errors',1);
error_reporting(-1);

require('../fpdf/fpdf.php');

$pdf = new FPDF();

$pdf->AddPage();

$pdf->AddFont('MVBoli',NULL,'mvboli.php');

$pdf->SetFont('MVBoli',NULL,16);

$pdf->Cell(0,10,'Example text goes here.');

$pdf->Output('mvboli_font.pdf','D');

?>