$(function(){
  $('.modaltrigger').leanModal({ top: 110, overlay: 0.45, closeButton: ".modal_close" });
});