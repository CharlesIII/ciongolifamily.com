$(function(){
    // set interval for 5 minutes
    setInterval(function(){
        $.ajax({url: "images/0.png"});
    }, 300000);
});