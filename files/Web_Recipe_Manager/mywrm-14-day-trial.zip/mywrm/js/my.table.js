$(document).ready(function() {
    $("#usermaint").tablesorter({widgets: ['zebra']}); 
});